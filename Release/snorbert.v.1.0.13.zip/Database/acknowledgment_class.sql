CREATE TABLE `acknowledgment_class` (
	`id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
	`desc` VARCHAR(35) NOT NULL,
	PRIMARY KEY (`id`)
)
COLLATE='latin1_swedish_ci'
ENGINE=InnoDB;